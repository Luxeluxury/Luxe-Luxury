export default async function handler(req, res) {
  // Allow CORS from anywhere (your GitHub Pages site)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const CF_APP_ID     = process.env.CF_APP_ID;
  const CF_SECRET_KEY = process.env.CF_SECRET_KEY;

  if (!CF_APP_ID || !CF_SECRET_KEY) {
    return res.status(500).json({ error: 'Server not configured' });
  }

  try {
    const { orderId, amount, customerName, customerPhone } = req.body;

    const response = await fetch('https://api.cashfree.com/pg/orders', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-client-id': CF_APP_ID,
        'x-client-secret': CF_SECRET_KEY,
        'x-api-version': '2023-08-01',
      },
      body: JSON.stringify({
        order_id: orderId,
        order_amount: amount,
        order_currency: 'INR',
        customer_details: {
          customer_id: 'CUST_' + customerPhone,
          customer_phone: '91' + customerPhone,
          customer_name: customerName,
        },
        order_meta: {
          return_url: req.headers.origin || 'https://yourgithubsite.github.io',
        },
      }),
    });

    const data = await response.json();
    return res.status(response.status).json(data);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
}
